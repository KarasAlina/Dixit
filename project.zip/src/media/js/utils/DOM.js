module.exports = {
	$body: $('body'),
	$html: $('html'),
	$document: $(document),
	$window: $(window),
};
